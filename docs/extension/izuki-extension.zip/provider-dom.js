(function(root) {
async function typeIntoComposer(text, composerSelectors, sendSelectors, autoSend, expectedOrigin = "", requestId = "", deadline = 0) {
  if (expectedOrigin && location.origin !== expectedOrigin) return { ok: false, why: "changed-page" };
  // The relay stopped waiting for this call (it took too long, or Stop):
  // checked here and after every wait, before the box is touched again.
  const gone = () => (deadline && Date.now() > deadline) || Boolean(requestId && globalThis.__izukiStoppedRelay?.has(requestId));
  if (gone()) return { ok: false, why: "stopped" };
  const visible = (el) => {
    if (!el) return false;
    const box = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return box.width > 1 && box.height > 1 && style.visibility !== "hidden" && style.display !== "none";
  };
  let box;
  for (const selector of composerSelectors) {
    const matches = [...new Set([...document.querySelectorAll(selector)].filter(visible))];
    if (matches.length > 1) return { ok: false, why: "ambiguous" };
    if (matches.length === 1) { box = matches[0]; break; }
  }
  if (!box) return { ok: false, why: "no-composer" };
  if (box.disabled || box.readOnly || box.getAttribute("aria-disabled") === "true" || box.getAttribute("type") === "password") return { ok: false, why: "busy" };
  // A draft the person typed is left alone. Text Izuki typed itself on an
  // earlier try (its Send failed or was swallowed) is Izuki's: it's replaced,
  // instead of every later question failing on "your tab has a draft".
  const squash = (s) => String(s || "").replace(/\s+/g, " ").trim();
  const native = box.tagName === "TEXTAREA" || box.tagName === "INPUT";
  // innerText preserves rendered paragraph/<br> boundaries. textContent
  // would join <p>First</p><p>Second</p> into "FirstSecond" and reject an
  // otherwise exact multiline paste (or mistake our leftover for a draft).
  const inBox = () => squash(native ? box.value : (box.innerText ?? box.textContent));
  const draft = inBox();
  const mine = squash(globalThis.__izukiTyped);
  const current = () => (!expectedOrigin || location.origin === expectedOrigin)
    && box.isConnected && visible(box) && !box.disabled && !box.readOnly
    && box.getAttribute("aria-disabled") !== "true"
    && box.getAttribute("type") !== "password"
    && composerSelectors.some((selector) => [...document.querySelectorAll(selector)].includes(box));
  // (Exactly Izuki's text: anything the person added or changed is theirs.)
  if (draft && !(mine && draft === mine)) return { ok: false, why: "draft" };
  if ([...document.querySelectorAll('button[data-testid="stop-button"],button[aria-label*="Stop generating" i],button[aria-label*="Stop response" i]')].some(visible)) return { ok: false, why: "busy" };

  box.focus();
  if (!current()) return { ok: false, why: "changed-page" };
  // React tracks the value on the element; set it through the prototype
  // setter so its own onChange fires instead of being skipped.
  const setValue = (value) => {
    if (native) {
      const setter = Object.getOwnPropertyDescriptor(
        box.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
        "value"
      )?.set;
      if (setter) setter.call(box, value);
      else box.value = value;
    } else {
      box.textContent = value;
    }
    box.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
    box.dispatchEvent(new Event("change", { bubbles: true }));
  };
  if (draft) {
    // Izuki's own leftover: cleared the way a person would (select it all,
    // delete), then checked, before anything new goes in.
    if (native) setValue("");
    else {
      const range = document.createRange();
      range.selectNodeContents(box);
      const sel = getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand("delete");
      await new Promise((resolve) => setTimeout(resolve, 80));
      if (gone()) return { ok: false, why: "stopped" };
      if (!current()) return { ok: false, why: "changed-page" };
    }
    if (inBox()) return { ok: false, why: "draft" };
  }
  if (!native) {
    // A contenteditable editor: paste, which Lexical and ProseMirror both
    // understand. Their handler is asynchronous, so the text is checked
    // after it has had a moment before anything is typed over it.
    const data = new DataTransfer();
    data.setData("text/plain", text);
    box.dispatchEvent(new ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true }));
    // A cancelled paste still owns any unchanged text it inserted.
    globalThis.__izukiTyped = text;
    await new Promise((resolve) => setTimeout(resolve, 120));
    if (gone()) return { ok: false, why: "stopped" };
  }
  // Did the words actually land? A paste event is a request, not a paste:
  // an editor can cancel it and insert nothing, and synthetic input is
  // frequently discarded on the next render. Pressing Send after that sends
  // an empty message — the panel would say "handed over" while nothing was
  // asked, which is the worst possible answer.
  const expected = squash(text);
  const landed = () => Boolean(expected) && inBox() === expected;
  if (!current()) return { ok: false, why: "changed-page" };
  if (!landed()) {
    if (gone()) return { ok: false, why: "stopped" };
    if (inBox()) return { ok: false, why: "draft" };
    globalThis.__izukiTyped = text;
    setValue(text);
    // An editor that re-renders from its own state throws a plain text node
    // away on the next frame. Give it that frame, then believe what's there.
    if (!native) await new Promise((resolve) => setTimeout(resolve, 120));
    if (gone()) return { ok: false, why: "stopped" };
    if (!current()) return { ok: false, why: "changed-page" };
    if (!landed()) return { ok: false, why: inBox() ? "draft" : "no-text" };
  }

  // Remembered as Izuki's, so a failed Send doesn't block the next question.
  globalThis.__izukiTyped = text;
  if (!autoSend) return { ok: true, sent: false };
  const ready = (el) => visible(el) && !el.disabled && el.getAttribute("aria-disabled") !== "true";
  const form = box.closest?.("form");
  let button;
  for (const selector of sendSelectors) {
    // A generic Submit belongs to this composer, never an unrelated form.
    const scope = selector === 'button[type="submit"]' ? form : document;
    if (!scope) continue;
    const matches = [...new Set([...scope.querySelectorAll(selector)].filter(ready))];
    if (matches.length === 1) { button = matches[0]; break; }
    if (matches.length > 1) return { ok: false, why: "ambiguous-send" };
  }
  if (button) {
    if (requestId && globalThis.__izukiStoppedRelay?.has(requestId)) return {ok:false,why:"stopped"};
    if (deadline && Date.now() > deadline) return { ok: false, why: "stopped" };
    if (!current()) return { ok: false, why: "changed-page" };
    if (!landed()) return { ok: false, why: "draft" };
    button.click();
    // Sent: whatever is in the box from now on is the person's.
    globalThis.__izukiTyped = "";
    return { ok: true, sent: true };
  }
  return { ok: false, why: "no-send" };
}


// Runs in the connected tab. Never falls back to the whole page or form values.
function readAssistant(responseSelectors, userSelectors, expectedOrigin) {
  if (location.origin !== expectedOrigin) return {ok:false,why:"changed-page"};
  const visible = el => {
    if (!el || el.closest('textarea,input,[contenteditable="true"],[hidden],[aria-hidden="true"],[data-message-author-role="user"]')) return false;
    const style=getComputedStyle(el), box=el.getBoundingClientRect();
    return style.display!=="none" && style.visibility!=="hidden" && box.width>0 && box.height>0;
  };
  let nodes=[];
  for (const selector of responseSelectors.slice(0,8)) {
    nodes=[...document.querySelectorAll(selector)].filter(visible);
    if (nodes.length) break;
  }
  let user="";
  for(const selector of userSelectors.slice(0,8)) {
    const found=[...document.querySelectorAll(selector)].filter(el=>{
      const box=el.getBoundingClientRect(),style=getComputedStyle(el);
      return box.width>0&&box.height>0&&style.display!=="none"&&style.visibility!=="hidden";
    });
    if(found.length){user=(found.at(-1).innerText||found.at(-1).textContent||"").slice(0,18000);break;}
  }
  const stopSelectors='button[data-testid="stop-button"],button[aria-label*="Stop generating" i],button[aria-label*="Stop response" i],button[aria-label*="Stop answering" i],button[aria-label="Stop" i],button.stop-button';
  const busy=[...document.querySelectorAll(stopSelectors)].some(el=>{
    const box=el.getBoundingClientRect(),style=getComputedStyle(el);
    return box.width>0&&box.height>0&&style.display!=="none"&&style.visibility!=="hidden";
  });
  const last=nodes.at(-1);
  return {ok:true,count:nodes.length,text:last?String(last.innerText||last.textContent||"").trim().slice(0,18000):"",user,busy};
}
root.IzukiProviderDOM = { typeIntoComposer, readAssistant };
})(globalThis);
