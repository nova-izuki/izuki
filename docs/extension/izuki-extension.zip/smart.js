// Izuki's smart features inside the browser — on their own, not just as
// Izuki's eyes for the orb:
//  • right-click: Explain / Translate / Sum up / Read aloud / Save to Nova
//    Notes / Remind me later on selected text; Sum up this link; Sum up or
//    save the whole page;
//  • the side panel (toolbar icon or Alt+Shift+I): ask anything about the
//    page you're on, and your other tabs, in a running conversation;
//  • Focus guard: during Izuki's Focus mode, a gentle nudge on distracting
//    sites.
// Answers come from Izuki on this PC, with your own AI — the extension holds
// no keys. Read aloud uses the browser's own voice, so it works offline.

const BRIDGE_URL = "http://127.0.0.1:47615/izuki";
const JSON_HEADERS = { "X-Izuki-Extension": "1", "Content-Type": "application/json" };

async function izuki(path, body) {
  // The selection goes only to Izuki itself (bridge-proof.js).
  const proof = await globalThis.IzukiBridgeProof.check();
  if (!proof.ok) return { ok: false, text: globalThis.IzukiBridgeProof.message[proof.why] };
  try {
    const r = await fetch(`${BRIDGE_URL}/${path}`, { method: "POST", headers: JSON_HEADERS, body: JSON.stringify(body || {}) });
    // An older Izuki on the PC doesn't know these yet.
    if (r.status === 404) return { ok: false, text: "Update Izuki on your PC (it updates itself — or restart it) to use this." };
    return await r.json();
  } catch {
    return { ok: false, text: "Izuki isn't running on this PC — open the Izuki app, then try again." };
  }
}

// ---- the right-click menu ---------------------------------------------------

const MENU = [
  { id: "izk-panel", title: "Ask Izuki about this…", contexts: ["selection", "page"] },
  { id: "izk-explain", title: "Explain this", contexts: ["selection"] },
  { id: "izk-translate", title: "Translate to English", contexts: ["selection"] },
  { id: "izk-summarise", title: "Sum it up", contexts: ["selection"] },
  { id: "izk-read", title: "Read it aloud", contexts: ["selection"] },
  { id: "izk-note", title: "Save to Izuki Notes", contexts: ["selection"] },
  { id: "izk-later", title: "Remind me later", contexts: ["selection"] },
  { id: "izk-link", title: "Sum up this link", contexts: ["link"] },
  { id: "izk-page", title: "Sum up this page", contexts: ["page"] },
  { id: "izk-page-note", title: "Save this page to Izuki Notes", contexts: ["page"] },
  { id: "izk-page-read", title: "Read this page aloud", contexts: ["page"] },
];

function buildMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "izk", title: "Izuki", contexts: ["selection", "link", "page"] });
    for (const m of MENU) chrome.contextMenus.create({ ...m, parentId: "izk" });
  });
}
chrome.runtime.onInstalled.addListener(buildMenu);
// The toolbar icon opens the side panel, like Chrome's own assistant.
chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {});

/** Open the side panel (needs the click/keypress that led here), with a question to ask or just ready to type. */
function openPanel(tab, question) {
  try { chrome.sidePanel.open({ windowId: tab.windowId }); } catch {}
  chrome.storage.session.set({ izkPending: { question: question || "", at: Date.now() } }).catch(() => {});
}
chrome.runtime.onStartup.addListener(buildMenu);

async function pageText(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => (document.body ? document.body.innerText : "").replace(/\n{3,}/g, "\n\n").slice(0, 14000),
    });
    return r ? r.result : "";
  } catch {
    return "";
  }
}

function speak(text) {
  chrome.tts.stop();
  chrome.tts.speak(String(text).slice(0, 30000), { rate: 1.0, enqueue: false });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || !tab.id) return;
  const sel = (info.selectionText || "").trim();
  const base = { title: tab.title || "", url: tab.url || "" };
  const show = (heading, body, opts) => bubble(tab.id, heading, body, opts);
  switch (info.menuItemId) {
    case "izk-panel":
      return openPanel(tab, sel ? `About this: “${sel.slice(0, 600)}” — explain it and tell me what matters.` : "");
    case "izk-explain":
    case "izk-translate":
    case "izk-summarise": {
      const task = { "izk-explain": "explain", "izk-translate": "translate", "izk-summarise": "summarise" }[info.menuItemId];
      const heading = { explain: "Explained", translate: "Translation", summarise: "In short" }[task];
      await show(heading, "…", { loading: true });
      const r = await izuki("ask", { ...base, task, text: sel, web: false });
      return show(heading, r.text, { ok: r.ok });
    }
    case "izk-read":
      speak(sel);
      return show("Reading aloud", "Reading it now. Click Stop to end.", { stopVoice: true });
    case "izk-note": {
      const r = await izuki("note", { ...base, text: sel, page: false });
      return show("Izuki Notes", r.text, { ok: r.ok, brief: true });
    }
    case "izk-later": {
      const r = await izuki("later", { text: sel });
      return show("Later list", r.text, { ok: r.ok, brief: true });
    }
    case "izk-link": {
      await show("That link, in short", "…", { loading: true });
      const r = await izuki("ask", { ...base, task: "link", text: info.linkUrl || "", web: false });
      return show("That link, in short", r.text, { ok: r.ok });
    }
    case "izk-page": {
      await show("This page, in short", "…", { loading: true });
      const r = await izuki("ask", { ...base, task: "summarise", text: await pageText(tab.id), web: false });
      return show("This page, in short", r.text, { ok: r.ok });
    }
    case "izk-page-note": {
      await show("Izuki Notes", "Making notes from this page…", { loading: true });
      const r = await izuki("note", { ...base, text: await pageText(tab.id), page: true });
      return show("Izuki Notes", r.text, { ok: r.ok, brief: true });
    }
    case "izk-page-read":
      speak(await pageText(tab.id));
      return show("Reading aloud", "Reading this page now. Click Stop to end.", { stopVoice: true });
  }
});

// ---- the answer bubble, on the page --------------------------------------------

async function bubble(tabId, heading, body, opts = {}) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, func: drawBubble, args: [heading, String(body || ""), opts] });
  } catch {
    /* a browser page Izuki can't draw on */
  }
}

// Runs inside the page.
function drawBubble(heading, body, opts) {
  const ID = "izuki-bubble-host";
  const pad = 12;
  let host = document.getElementById(ID);
  if (!host) {
    host = document.createElement("div");
    host.id = ID;
    // Only the card catches a pointer; the empty space around it lets clicks
    // reach the page. The card can also be dragged, and moves itself off a
    // control the desktop task is about to press.
    host.style.cssText = "position:fixed;z-index:2147483647;top:16px;right:16px;pointer-events:none;";
    document.documentElement.appendChild(host);
    host.attachShadow({ mode: "open" });
  }
  // An older card may already be on the page without this rule.
  host.style.pointerEvents = "none";
  const root = host.shadowRoot;
  root.innerHTML = `
    <style>
      .b{width:min(380px,90vw);max-height:60vh;overflow:auto;font:14px/1.5 "Segoe UI",system-ui,sans-serif;color:#f4f1fb;
         background:rgba(12,11,26,.96);border:1px solid rgba(167,139,250,.45);border-radius:16px;padding:14px 16px;
         box-shadow:0 18px 50px rgba(0,0,0,.45);backdrop-filter:blur(10px);animation:in .18s ease-out;
         pointer-events:auto;touch-action:none}
      @keyframes in{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}
      .h{display:flex;align-items:center;gap:8px;font-weight:700;font-size:13px;letter-spacing:.02em;color:#c4b5fd;margin-bottom:6px;
         cursor:grab;user-select:none;touch-action:none}
      .h:active{cursor:grabbing}
      .dot{width:9px;height:9px;border-radius:50%;background:linear-gradient(135deg,#7c5cff,#4ecdc4);flex:none}
      .hd{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .x{margin-left:auto;background:none;border:0;color:#aaa6bf;font-size:18px;cursor:pointer;line-height:1;pointer-events:auto}
      .t{white-space:pre-wrap}
      .bad{color:#fca5a5}
      .row{display:flex;gap:6px;margin-top:10px}
      .row button{font:inherit;font-size:12px;padding:4px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);color:#f4f1fb;cursor:pointer}
      .row button:hover{background:rgba(255,255,255,.14)}
      .b.mini .t,.b.mini .row{display:none}
      .b.mini{width:auto;max-width:min(280px,86vw)}
      .spin{display:inline-block;width:12px;height:12px;border:2px solid #67e8f9;border-top-color:transparent;border-radius:50%;animation:s .8s linear infinite;vertical-align:-2px;margin-right:6px}
      @keyframes s{to{transform:rotate(360deg)}}
    </style>
    <div class="b" role="dialog" aria-label="Izuki">
      <div class="h" title="Drag to move out of the way"><span class="dot"></span><span class="hd"></span><button class="x" title="Close">×</button></div>
      <div class="t"></div>
      <div class="row"></div>
    </div>`;
  root.querySelector(".hd").textContent = heading;
  const t = root.querySelector(".t");
  if (opts.loading) t.innerHTML = '<span class="spin"></span>Thinking…';
  else t.textContent = body;
  if (opts.ok === false) t.classList.add("bad");
  root.querySelector(".x").onclick = () => host.remove();
  const row = root.querySelector(".row");
  const btn = (label, fn) => { const b = document.createElement("button"); b.textContent = label; b.onclick = fn; row.appendChild(b); };
  if (!opts.loading && !opts.brief && opts.ok !== false && !opts.stopVoice) {
    btn("Copy", () => navigator.clipboard.writeText(body));
    btn("Read aloud", () => chrome.runtime.sendMessage({ izukiSpeak: body }));
  }
  if (opts.stopVoice) btn("Stop", () => { chrome.runtime.sendMessage({ izukiStop: true }); host.remove(); });
  if (opts.brief) setTimeout(() => host.remove(), 4000);

  const card = root.querySelector(".b");
  const header = root.querySelector(".h");
  const clamp = (value, lo, hi) => Math.max(lo, Math.min(value, hi));
  const place = (left, top) => {
    const box = card.getBoundingClientRect();
    host.style.left = `${Math.round(clamp(left, pad, Math.max(pad, innerWidth - box.width - pad)))}px`;
    host.style.top = `${Math.round(clamp(top, pad, Math.max(pad, innerHeight - box.height - pad)))}px`;
    host.style.right = "auto";
    host.style.bottom = "auto";
  };
  const overlap = (box, target) =>
    box.left < target.right + pad && box.right + pad > target.left &&
    box.top < target.bottom + pad && box.bottom + pad > target.top;
  /** Called just before the page clicks or types: get off that control. */
  globalThis.__izukiBubbleDodge = (target) => {
    if (!host.isConnected || !target) return false;
    const box = card.getBoundingClientRect();
    if (!overlap(box, target)) return false;
    const corners = [
      { left: innerWidth - box.width - pad, top: pad },
      { left: pad, top: pad },
      { left: innerWidth - box.width - pad, top: innerHeight - box.height - pad },
      { left: pad, top: innerHeight - box.height - pad },
    ];
    // Nearest free corner, so the answer stays where the eye last saw it.
    const free = corners
      .filter((corner) => !overlap({ left: corner.left, right: corner.left + box.width, top: corner.top, bottom: corner.top + box.height }, target))
      .sort((a, b) => Math.hypot(a.left - box.left, a.top - box.top) - Math.hypot(b.left - box.left, b.top - box.top));
    if (free.length) { place(free[0].left, free[0].top); return true; }
    // A page too tight for any free corner: keep the title bar only, at the
    // corner farthest from the control, so the page behind is still usable.
    card.classList.add("mini");
    const far = corners
      .map((corner) => ({ ...corner, distance: Math.hypot(corner.left - target.left, corner.top - target.top) }))
      .sort((a, b) => b.distance - a.distance)[0];
    place(far.left, far.top);
    return true;
  };
  let drag = null;
  header.addEventListener("pointerdown", (event) => {
    if (event.target.closest(".x")) return;
    const box = card.getBoundingClientRect();
    drag = { dx: event.clientX - box.left, dy: event.clientY - box.top };
    try { header.setPointerCapture(event.pointerId); } catch {}
    event.preventDefault();
  });
  header.addEventListener("pointermove", (event) => {
    if (!drag) return;
    place(event.clientX - drag.dx, event.clientY - drag.dy);
  });
  const stopDrag = (event) => {
    if (!drag) return;
    drag = null;
    try { header.releasePointerCapture(event.pointerId); } catch {}
  };
  header.addEventListener("pointerup", stopDrag);
  header.addEventListener("pointercancel", stopDrag);
}
chrome.runtime.onMessage.addListener((m) => {
  if (m && m.izukiSpeak) speak(m.izukiSpeak);
  if (m && m.izukiStop) chrome.tts.stop();
  if (m && m.izukiAsk) {
    // A question about the page in front, answered in a bubble on the page.
    (async () => {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (!tab || !tab.id) return;
      await bubble(tab.id, "About this page", "…", { loading: true });
      const r = await izuki("ask", { title: tab.title, url: tab.url, task: m.izukiAsk.task || "ask", question: m.izukiAsk.question || "", text: await pageText(tab.id), web: true });
      await bubble(tab.id, m.izukiAsk.task === "summarise" ? "This page, in short" : "About this page", r.text, { ok: r.ok });
    })();
  }
});

// ---- Alt+Shift+I: open the side panel ------------------------------------------------

chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (cmd !== "ask-page") return;
  const t = tab || (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
  if (t) openPanel(t, "");
});

// ---- Focus guard ------------------------------------------------------------------------

const DISTRACTING = /(^|\.)(youtube\.com|tiktok\.com|instagram\.com|facebook\.com|twitter\.com|x\.com|reddit\.com|netflix\.com|twitch\.tv|snapchat\.com|pinterest\.com)$/;
const snoozedUntil = {};

chrome.tabs.onUpdated.addListener(async (tabId, change, tab) => {
  if (change.status !== "complete" || !tab.url) return;
  let host = "";
  try { host = new URL(tab.url).hostname; } catch { return; }
  if (!DISTRACTING.test(host) || (snoozedUntil[host] || 0) > Date.now()) return;
  const f = await izuki("focus", {});
  if (!f.ok || !f.left) return;
  const mins = Math.max(1, Math.ceil(f.left / 60));
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: focusNudge, args: [mins] });
    if (r && r.result === "snooze") snoozedUntil[host] = Date.now() + 5 * 60000;
  } catch {
    /* ignore */
  }
});

// Runs inside the page: a calm full-page card. Resolves "back" or "snooze".
function focusNudge(mins) {
  return new Promise((resolve) => {
    const host = document.createElement("div");
    host.style.cssText = "position:fixed;inset:0;z-index:2147483647;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        .w{position:fixed;inset:0;display:grid;place-items:center;background:rgba(6,6,16,.86);backdrop-filter:blur(8px);font:16px/1.5 "Segoe UI",system-ui,sans-serif;color:#f4f1fb}
        .c{text-align:center;max-width:420px;padding:28px}
        .o{width:72px;height:72px;margin:0 auto 14px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#e0f7ff,#7c5cff 55%,#140f30)}
        h2{margin:0 0 6px;font-size:22px} p{margin:0 0 18px;color:#cfd3f5}
        button{font:inherit;padding:10px 18px;border-radius:999px;border:0;margin:4px;cursor:pointer}
        .a{background:linear-gradient(135deg,#7c5cff,#4ecdc4);color:#fff;font-weight:600}
        .s{background:rgba(255,255,255,.1);color:#f4f1fb}
      </style>
      <div class="w"><div class="c"><div class="o"></div>
        <h2>You're focusing 🎯</h2><p>${mins} minute${mins === 1 ? "" : "s"} left in your focus session. This can wait — you've got this.</p>
        <button class="a">Back to work</button><button class="s">Just 5 minutes</button></div></div>`;
    document.documentElement.appendChild(host);
    root.querySelector(".a").onclick = () => { host.remove(); resolve("back"); history.length > 1 ? history.back() : (location.href = "about:blank"); };
    root.querySelector(".s").onclick = () => { host.remove(); resolve("snooze"); };
  });
}
