// Izuki's side panel: ask about the page you're on, like a friend reading
// along. It follows the tab in front, can take in other open tabs too, and
// keeps the conversation going. Answers come from Izuki on this PC.

import { setUpConnection } from "./connect.js";

const BRIDGE = "http://127.0.0.1:47615/izuki";
// Set once the connection controls are wired; until then every question goes
// to Izuki on this PC, which is what the panel has always done.
let handToProvider = null;
let connected = null;
const H = { "X-Izuki-Extension": "1", "Content-Type": "application/json" };
const $ = (id) => document.getElementById(id);
const log = $("log");

/** The conversation: { role: "user" | "assistant", content } (kept for this browser session). */
let history = [];
let current = null; // the tab in front: { id, title, url, favIconUrl }
let extra = new Set(); // other tab ids the user shared
let busy = null; // AbortController while waiting

const store = {
  async get() {
    try { return (await chrome.storage.session.get("izkPanel")).izkPanel || null; } catch { return null; }
  },
  set(v) { try { chrome.storage.session.set({ izkPanel: v }); } catch {} },
};
const save = () => store.set({ history });

// ---- talking to Izuki on the PC ------------------------------------------------

async function ping() {
  const st = $("state");
  try {
    const r = await fetch(`${BRIDGE}/ping`, { headers: H });
    if (!r.ok) throw 0;
    st.className = "on";
    st.innerHTML = "<i></i>Connected";
    try {
      const f = await (await fetch(`${BRIDGE}/focus`, { method: "POST", headers: H, body: "{}" })).json();
      if (f.left) st.innerHTML += ` · 🎯 Focus ${Math.ceil(f.left / 60)} min`;
    } catch {}
    return true;
  } catch {
    st.className = "off";
    st.innerHTML = "<i></i>Izuki isn't running";
    return false;
  }
}

/** What's on a tab: its words (and what's selected), or null when the browser won't let anyone read it. */
async function readTab(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({
        text: (document.body ? document.body.innerText : "").replace(/\n{3,}/g, "\n\n").slice(0, 14000),
        selection: String(getSelection() || "").slice(0, 3000),
        links: [...document.links].slice(0, 400).map((a) => ({ name: (a.innerText || a.title || a.getAttribute("aria-label") || "").trim().slice(0, 80), href: a.href })).filter((l) => l.name && /^https?:/.test(l.href)),
      }),
    });
    return r ? r.result : null;
  } catch {
    return null;
  }
}

// ---- the page in front --------------------------------------------------------------

async function follow() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab) return;
  const moved = current && current.id !== tab.id && history.length > 0;
  current = { id: tab.id, title: tab.title || tab.url || "This page", url: tab.url || "", favIconUrl: tab.favIconUrl || "" };
  $("ptitle").textContent = current.title;
  $("ptitle").title = current.url;
  const fav = $("fav");
  if (current.favIconUrl && /^https?:|^data:/.test(current.favIconUrl)) { fav.src = current.favIconUrl; fav.hidden = false; } else fav.hidden = true;
  extra.delete(tab.id);
  if (moved) divider(`Now on: ${current.title}`);
  drawTabs();
  if (!history.length) hello();
}

async function drawTabs() {
  const box = $("tabs");
  box.textContent = "";
  const tabs = (await chrome.tabs.query({ lastFocusedWindow: true })).filter((t) => current && t.id !== current.id && /^https?:/.test(t.url || ""));
  if (!tabs.length) return;
  for (const t of tabs.slice(0, 8)) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "chip" + (extra.has(t.id) ? " on" : "");
    b.textContent = (extra.has(t.id) ? "✓ " : "＋ ") + (t.title || t.url);
    b.title = extra.has(t.id) ? "Shared — click to stop sharing" : "Share this tab too (compare, combine)";
    b.onclick = () => { extra.has(t.id) ? extra.delete(t.id) : extra.size < 4 && extra.add(t.id); drawTabs(); };
    box.appendChild(b);
  }
}

// ---- the conversation ---------------------------------------------------------------

function esc(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}

/** Light formatting for answers: paragraphs, - bullets, **bold**, `code`, links. */
function render(text) {
  const inline = (s) =>
    esc(s)
      .replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\bhttps?:\/\/[^\s<)]+/g, (u) => `<a href="${u}" target="_blank" rel="noopener">${u}</a>`);
  const out = [];
  let list = null;
  for (const raw of String(text).split("\n")) {
    const line = raw.trim();
    const bullet = line.match(/^(?:[-*•]|\d+[.)])\s+(.*)/);
    if (bullet) {
      if (!list) { list = []; out.push(list); }
      list.push(`<li>${inline(bullet[1])}</li>`);
    } else {
      list = null;
      if (line) out.push(`<p>${inline(line.replace(/^#+\s*/, ""))}</p>`);
    }
  }
  return out.map((x) => (Array.isArray(x) ? `<ul>${x.join("")}</ul>` : x)).join("");
}

function bubble(role, content, bad = false) {
  log.querySelector(".hello")?.remove();
  const el = document.createElement("div");
  el.className = `msg ${role === "user" ? "me" : "it"}${bad ? " bad" : ""}`;
  if (role === "user") el.textContent = content;
  else {
    el.innerHTML = render(content);
    if (!bad) {
      const acts = document.createElement("div");
      acts.className = "acts";
      const act = (label, fn) => { const b = document.createElement("button"); b.className = "icon"; b.type = "button"; b.textContent = label; b.onclick = fn; acts.appendChild(b); };
      act("Copy", () => navigator.clipboard.writeText(content));
      act("Read aloud", () => chrome.runtime.sendMessage({ izukiSpeak: content }));
      act("Save to Notes", async () => {
        try {
          const n = await (await fetch(`${BRIDGE}/note`, { method: "POST", headers: H, body: JSON.stringify({ title: current?.title || "", url: current?.url || "", text: content, page: false }) })).json();
          divider(n.text);
        } catch { divider("Izuki isn't running on this PC."); }
      });
      el.appendChild(acts);
    }
  }
  log.appendChild(el);
  log.scrollTop = log.scrollHeight;
  return el;
}

function divider(text) {
  const d = document.createElement("div");
  d.className = "divider";
  d.textContent = text;
  log.appendChild(d);
  log.scrollTop = log.scrollHeight;
}

function hello() {
  if (log.querySelector(".hello")) return;
  log.textContent = "";
  const url = current?.url || "";
  const ideas = [
    ["📝 Sum up this page", "Sum up this page in a few short bullet points."],
    ["✅ What do I need to do here?", "What do I need to do on this page? Give me the steps."],
    ["💡 Explain it simply", "Explain this page simply, like I'm 12."],
    ["🔎 Key facts and numbers", "What are the key facts, dates and numbers on this page?"],
  ];
  if (/youtube\.com\/watch|youtu\.be\//.test(url)) ideas.unshift(["🎬 What's this video about?", "What's this video about? Use the title, description and anything shown on the page."]);
  if (/amazon\.|ebay\.|walmart\.|shop|store|product|cart/.test(url)) ideas.push(["🛒 Is this a good buy?", "Is this a good buy? Sum up the price, reviews and anything to watch out for."]);
  if (/mail\.google|outlook\.|mail\./.test(url)) ideas.push(["✉️ Draft a reply", "Draft a short, friendly reply to the email that's open."]);
  ideas.push(["🛡️ Is this site trustworthy?", "Does anything on this page look like a scam or something to be careful about?"]);
  const box = document.createElement("div");
  box.className = "hello";
  box.innerHTML = `<h1>Hi, I'm Izuki</h1><div>Ask me anything about this page.</div><div class="ideas"></div>`;
  for (const [label, q] of ideas.slice(0, 6)) {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    b.onclick = () => ask(q);
    box.querySelector(".ideas").appendChild(b);
  }
  log.appendChild(box);
}

// ---- look-ahead: the answer is often behind a link -------------------------------------

const RISKY = /logout|log out|log-out|signout|sign out|sign-out|delete|remove|unsubscribe|cancel|submit|checkout|buy|pay|purchase|order|confirm|approve|reset/i;
const SKIP = new Set(["what", "which", "where", "when", "does", "this", "that", "with", "from", "have", "about", "there", "their", "page", "please", "answer", "question", "tell"]);
const EXPLAINERS = /syllabus|instructions|details|rubric|assignment|overview|guidelines|readme|docs|documentation|faq/i;

/** The page's links most related to the question (never ones whose visit could change something). */
function relatedLinks(links, question, pageUrl, max = 3) {
  const words = question.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length >= 3 && !SKIP.has(w));
  const host = (u) => { try { return new URL(u).host; } catch { return ""; } };
  const here = host(pageUrl), seen = new Set(), out = [];
  for (const l of links || []) {
    if (seen.has(l.href) || l.href.split("#")[0] === pageUrl.split("#")[0] || RISKY.test(l.name + " " + l.href)) continue;
    seen.add(l.href);
    const name = l.name.toLowerCase();
    let score = words.filter((w) => name.includes(w)).length * 10 + (EXPLAINERS.test(name) ? 3 : 0) + (host(l.href) === here ? 2 : 0);
    if (score >= 10) out.push({ ...l, score });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, max);
}

/** A linked page's words, read quietly with your own sign-ins. */
async function readLinked(link) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 5000);
    const r = await fetch(link.href, { credentials: "include", signal: ctrl.signal });
    clearTimeout(t);
    if (!r.ok || !/html|text\/plain/.test(r.headers.get("content-type") || "")) return null;
    const doc = new DOMParser().parseFromString((await r.text()).slice(0, 600000), "text/html");
    doc.querySelectorAll("script,style,noscript,svg,nav,header,footer,template").forEach((n) => n.remove());
    const text = (doc.body ? doc.body.innerText || doc.body.textContent : "").replace(/\s*\n\s*\n+/g, "\n").replace(/[ \t]+/g, " ").trim();
    return text ? { title: link.name, url: link.href, text: text.slice(0, 3000) } : null;
  } catch {
    return null;
  }
}

async function ask(question) {
  question = String(question || "").trim();
  if (!question || busy || !current) return;
  // Another AI is answering: carry the question (and the page, if shared)
  // over to its tab instead of asking Izuki's own brain.
  const link = connected?.();
  if (link && !link.provider.local) {
    bubble("user", question);
    const share = $("share").checked;
    const page = share ? await readTab(current.id) : null;
    const carried = page
      ? `${question}\n\n--- the page I'm on: ${current.title} (${current.url}) ---\n${page.text.slice(0, 9000)}`
      : question;
    const problem = await handToProvider(carried);
    if (problem) bubble("assistant", problem, true);
    else divider(`Sent to ${link.provider.name}. The answer appears in that tab.`);
    $("q").focus();
    return;
  }
  bubble("user", question);
  const wait = document.createElement("div");
  wait.className = "msg it";
  wait.innerHTML = '<span class="dots"><span></span><span></span><span></span></span>';
  log.appendChild(wait);
  log.scrollTop = log.scrollHeight;
  busy = new AbortController();
  $("send").disabled = true;

  const share = $("share").checked;
  const page = share ? await readTab(current.id) : null;
  // Look-ahead: read the most related linked pages too.
  let linked = [];
  if (page && $("deep").checked) {
    const picks = relatedLinks(page.links, question, current.url);
    if (picks.length) {
      wait.innerHTML = `<span class="dots"><span></span><span></span><span></span></span> <small style="padding:0;background:none">Reading ${picks.map((p) => "“" + esc(p.name) + "”").join(", ")}…</small>`;
      linked = (await Promise.all(picks.map(readLinked))).filter(Boolean);
    }
  }
  const tabs = [];
  for (const id of extra) {
    const t = await chrome.tabs.get(id).catch(() => null);
    const r = t && (await readTab(id));
    if (r) tabs.push({ title: t.title || t.url, url: t.url, text: r.text });
  }
  const body = {
    task: "chat",
    question,
    title: share ? current.title : "(the user chose not to share the page)",
    url: share ? current.url : "",
    text: page ? page.text : "",
    selection: page ? page.selection : "",
    tabs,
    linked,
    history,
  };
  let answer, ok = false;
  try {
    const r = await fetch(`${BRIDGE}/ask`, { method: "POST", headers: H, body: JSON.stringify(body), signal: busy.signal });
    if (r.status === 404) answer = "Update Izuki on your PC (it updates itself — or restart it) to use this.";
    else { const j = await r.json(); answer = j.text; ok = !!j.ok; }
  } catch (e) {
    answer = e.name === "AbortError" ? "Stopped." : "Izuki isn't running on this PC — open the Izuki app, then ask again.";
    if (e.name !== "AbortError") ping();
  }
  wait.remove();
  if (share && !page && ok) divider("This page can't be read (a browser page or a PDF viewer) — I answered without it.");
  if (ok && linked.length) divider(`Also read: ${linked.map((l) => l.title).join(", ")}`);
  bubble("assistant", answer || "I couldn't come up with an answer.", !ok);
  if (ok) {
    history.push({ role: "user", content: question }, { role: "assistant", content: answer });
    history = history.slice(-20);
    save();
  }
  busy = null;
  $("send").disabled = false;
  $("q").focus();
}

// ---- wiring ---------------------------------------------------------------------------

const q = $("q");
$("ask").onsubmit = (e) => {
  e.preventDefault();
  const t = q.value;
  q.value = "";
  q.style.height = "";
  ask(t);
};
q.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("ask").requestSubmit(); }
  if (e.key === "Escape" && busy) busy.abort();
});
q.addEventListener("input", () => { q.style.height = ""; q.style.height = Math.min(q.scrollHeight, 140) + "px"; });
$("new").onclick = () => { if (busy) busy.abort(); history = []; save(); log.textContent = ""; hello(); };

chrome.tabs.onActivated.addListener(follow);
chrome.tabs.onUpdated.addListener((id, change) => { if (current && id === current.id && (change.title || change.status === "complete")) follow(); });
chrome.windows?.onFocusChanged?.addListener(() => follow());

// A question handed over from the right-click menu or Alt+Shift+I.
async function pending() {
  try {
    const { izkPending } = await chrome.storage.session.get("izkPending");
    if (!izkPending) return;
    await chrome.storage.session.remove("izkPending");
    if (izkPending.question) ask(izkPending.question);
    else q.focus();
  } catch {}
}
chrome.storage.onChanged.addListener((c, area) => { if (area === "session" && c.izkPending?.newValue) pending(); });

// ---- a task for Izuki on this PC ------------------------------------------

// An answer is never a command. A task runs only from this review box, with
// the person pressing Run — so an AI tab saying "download the project and
// edit it in Word" can't start doing that by itself.
const review = $("task-review");
export function reviewTask(text) {
  if (!review) return;
  $("task-text").value = String(text || "").trim();
  review.showModal();
}
$("task-cancel")?.addEventListener("click", () => review?.close());

const side = (route, body) =>
  fetch(`${BRIDGE}/side/${route}`, { method: "POST", headers: H, body: JSON.stringify(body) })
    .then((r) => r.json())
    .catch(() => ({ ok: false, text: "Izuki isn't running on this PC — open the Izuki app and try again." }));

$("task-run")?.addEventListener("click", async () => {
  const task = $("task-text").value.trim();
  review?.close();
  if (!task) return;
  bubble("user", task);
  // Prepared first, so what runs is exactly the words shown — the desktop
  // hands back a token and will not run anything without it.
  const requestId = crypto.randomUUID();
  if (!current?.id) return bubble("assistant", "Open the page you want Izuki to work from, then try again.", true);
  // The tab is part of the review: the desktop checks the task still
  // belongs to the page it was written about before it runs anything.
  const source = { requestId, prompt: task, tabId: current.id, url: current.url || "", title: current.title || "" };
  const ready = await side("prepare", source);
  if (!ready.ok) return bubble("assistant", ready.text || "Izuki wouldn't take that task.", true);
  const started = await side("run", { requestId, reviewToken: ready.reviewToken });
  if (!started.ok) return bubble("assistant", started.text || "Izuki wouldn't start that task.", true);

  divider("Izuki is doing that on your PC. Esc stops it, or press Stop here.");
  const stop = $("stop");
  if (stop) {
    stop.hidden = false;
    // Without the kind this cancels a chat and leaves the task running.
    stop.onclick = () => void side("stop", { requestId, kind: "task" });
  }
  // Poll until it's finished, so the panel says how it went rather than
  // leaving the person watching a page and guessing.
  const until = Date.now() + 15 * 60 * 1000;
  while (Date.now() < until) {
    await new Promise((r) => setTimeout(r, 1500));
    const now = await side("status", { requestId });
    if (!now.ok) break;
    if (now.state && now.state !== "running" && now.state !== "prepared") {
      bubble("assistant", now.text || "Done.", now.state === "cancelled");
      break;
    }
  }
  if (stop) {
    stop.hidden = true;
    stop.onclick = null;
  }
});

(async () => {
  const saved = await store.get();
  if (saved?.history?.length) {
    history = saved.history;
    for (const m of history) bubble(m.role, m.content);
  }
  await follow();
  ping();
  setInterval(ping, 15000);
  pending();
  q.focus();
  // The connection controls (which AI, follow the page, the companion).
  try {
    const wired = await setUpConnection({
      ask,
      onFollowed: (question, where) => {
        divider(`New question on ${where.title || "this page"}`);
        ask(question);
      },
    });
    handToProvider = wired.handToProvider;
    connected = wired.connected;
  } catch (e) {
    console.warn("[panel] connection controls:", e?.message || e);
  }
})();
