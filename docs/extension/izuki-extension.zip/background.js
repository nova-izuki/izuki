// Izuki for Chrome / Edge — the page's eyes and hands for Izuki on this PC.
//
// Izuki (the desktop app) runs a tiny bridge on 127.0.0.1:47615. This
// worker asks it for work ("next"), does it in the tab you're looking at,
// and posts the result back. Nothing leaves your PC; nothing runs unless
// Izuki asks.

// The smart features (right-click menu, answer bubble, focus guard).
importScripts("bridge-proof.js", "smart.js");
importScripts("workspace-state.js", "provider-specs.js", "provider-dom.js", "provider-relay.js", "question-page.js", "question-runner.js", "lab-state.js", "workspace-worker.js");

const BRIDGE = "http://127.0.0.1:47615/izuki";
// The version tells Izuki when this copy is too old for what it asks of it.
const HEADERS = { "X-Izuki-Extension": "1", "X-Izuki-Extension-Version": chrome.runtime.getManifest().version, "Content-Type": "application/json" };
let running = false;

// Is it really Izuki asking? While Izuki isn't running, any program can hold
// the bridge port, and this worker used to do whatever it was sent: read any
// page with your sign-ins, click and type in your tab. Now each job must be
// signed with the key Izuki wrote into this folder when it set the extension
// up (pairing.json, never readable by web pages), for a challenge this
// worker just made. Unsigned or wrongly signed: ignored.
let pairingKey = null;
const hexBytes = (h) => new Uint8Array(h.match(/../g).map((b) => parseInt(b, 16)));
async function bridgeKey() {
  if (pairingKey) return pairingKey;
  try {
    const { key } = await (await fetch(chrome.runtime.getURL("pairing.json"))).json();
    if (!/^[0-9a-f]{64}$/.test(key || "")) return null;
    pairingKey = await crypto.subtle.importKey("raw", hexBytes(key), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    return pairingKey;
  } catch {
    return null; // set up by hand, not by Izuki: no key, so no jobs
  }
}
const challenge = () => [...crypto.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, "0")).join("");
async function fromIzuki(reply, nonce, key) {
  if (typeof reply?.signed !== "string" || !/^[0-9a-f]{64}$/.test(reply.mac || "")) return null;
  const ok = await crypto.subtle.verify("HMAC", key, hexBytes(reply.mac), new TextEncoder().encode(`${nonce}\n${reply.signed}`));
  return ok ? JSON.parse(reply.signed) : null;
}

async function loop() {
  if (running) return;
  running = true;
  try {
    const key = await bridgeKey();
    if (!key) {
      console.warn("Izuki: this extension wasn't set up by Izuki on this PC (no pairing key), so it takes no jobs. Set it up from Izuki: Settings, Browser extension.");
      return;
    }
    for (;;) {
      let job;
      try {
        const nonce = challenge();
        const r = await IzukiBridgeProof.fetch(`${BRIDGE}/next`, { headers: { ...HEADERS, "X-Izuki-Nonce": nonce } });
        job = await fromIzuki(await r.json(), nonce, key);
      } catch {
        // Izuki isn't running: try again later (the alarm restarts us).
        return;
      }
      // Not signed by Izuki: whatever is on the port isn't Izuki. Stop (no
      // job, no answer, no busy loop) and try again later.
      if (!job) {
        console.warn("Izuki: an unsigned reply on the bridge port was ignored.");
        return;
      }
      if (!job.id || job.op === "none") continue;
      let result;
      try {
        result = { id: job.id, ok: true, data: await run(job.op, job.args || {}) };
      } catch (e) {
        result = { id: job.id, ok: false, error: String(e && e.message ? e.message : e) };
      }
      try {
        await IzukiBridgeProof.fetch(`${BRIDGE}/result`, { method: "POST", headers: HEADERS, body: JSON.stringify(result) });
      } catch {
        return;
      }
    }
  } finally {
    running = false;
  }
}

/** The tab a request is for: Izuki's pinned tab (where its task runs, even
 *  while you're on another tab), else the one in front. */
async function targetTab(args) {
  if (args && args.tab) {
    let t = null;
    try {
      t = await chrome.tabs.get(Number(args.tab));
    } catch {
      /* closed */
    }
    if (!t) throw new Error("Izuki's tab was closed");
    if (!/^https?:|^file:/.test(t.url || "")) throw new Error("this page can't be read (a browser page)");
    return t;
  }
  return activeTab();
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab || !tab.id) throw new Error("no browser tab in front");
  if (!/^https?:|^file:/.test(tab.url || "")) throw new Error("this page can't be read (a browser page)");
  return tab;
}

async function inPage(tabId, func, args = []) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, func, args });
  return res ? res.result : null;
}

/** Do one signed job from Izuki and return the operation's data. */
async function run(op, args) {
  // Blackboard's API needs no tab (and must work with none in front).
  if (op === "bbfetch") return await bbFetch(String(args.url || ""));
  // Where your school's site is: the addresses and titles of open tabs that
  // look like a learning site (nothing else is read from them).
  if (op === "lmstabs") {
    const tabs = await chrome.tabs.query({});
    return tabs
      .filter((t) => /^https:/.test(t.url || "") && (/blackboard|instructure|canvas|moodle|brightspace|d2l/i.test(t.url || "") || /Blackboard/.test(t.title || "")))
      .map((t) => ({ url: t.url, title: t.title || "" }));
  }
  // Pin the tab in front for a task; and is a pinned tab what you're looking at?
  if (op === "pin") {
    const t = await activeTab();
    return { tab: t.id, url: t.url, title: t.title || "" };
  }
  if (op === "tabinfo") {
    let t = null;
    try {
      t = await chrome.tabs.get(Number(args.tab));
    } catch {
      return { open: false, visible: false };
    }
    const w = await chrome.windows.get(t.windowId);
    return { open: true, tab: t.id, windowId: t.windowId, focused: !!w.focused, visible: !!t.active && w.state !== "minimized", url: t.url, title: t.title || "" };
  }
  const tab = await targetTab(args);
  switch (op) {
    case "snapshot":
      return { ...(await inPage(tab.id, snapshot)), url: tab.url, title: tab.title };
    case "click": {
      if (args.host) {
        const now = await chrome.tabs.get(tab.id).catch(() => null);
        const host = (() => { try { return new URL(now?.url || "").hostname.toLowerCase().replace(/^www\./, ""); } catch { return ""; } })();
        if (host !== String(args.host)) throw new Error("page_changed: the page moved on since I looked, so I didn't act. Taking a fresh look.");
      }
      const clicked = await inPage(tab.id, clickEl, [args.id]);
      if (!clicked) throw new Error("that element is gone");
      // A click still to come tells the app how long to wait before looking.
      return clicked === true ? true : { deferred: clicked.deferred };
    }
    case "type": {
      if (args.host) {
        const now = await chrome.tabs.get(tab.id).catch(() => null);
        const host = (() => { try { return new URL(now?.url || "").hostname.toLowerCase().replace(/^www\./, ""); } catch { return ""; } })();
        if (host !== String(args.host)) throw new Error("page_changed: the page moved on since I looked, so I didn't act. Taking a fresh look.");
      }
      const typed = await inPage(tab.id, typeEl, [args.id, String(args.text || "")]);
      if (typed === "secret") throw new Error("secret: I never type passwords, card numbers or security codes. You type that part, then tell me to carry on.");
      if (!typed) throw new Error("that box is gone");
      return true;
    }
    case "scroll":
      await inPage(tab.id, (dy) => window.scrollBy({ top: dy, behavior: "smooth" }), [Number(args.dy) || 600]);
      return true;
    case "skipad": {
      // One query inside YouTube's player, instead of walking every control
      // in the window from outside. Re-check the tab now: the person may
      // have switched tabs while the request was on its way, and autonomous
      // actions must never land in a tab they aren't looking at.
      const win = await chrome.windows.get(tab.windowId).catch(() => null);
      const now = await chrome.tabs.get(tab.id).catch(() => null);
      // Distinct from "YouTube is in front but has no Skip button": this
      // extension cannot see the foreground at all, so another browser may
      // be showing YouTube. Let the native side recheck and use the old walk.
      if (!win?.focused || !now?.active) return { skipped: false, no_foreground: true };
      return await inPage(tab.id, skipAd);
    }
    case "open":
      await chrome.tabs.update(tab.id, { url: String(args.url) });
      return true;
    case "readlinks": {
      // Look-ahead: pages linked from this one, read quietly with your own
      // sign-ins so the answer can come from behind the link. Only links that
      // are really on this page: never any address a request names.
      const links = new Set((await inPage(tab.id, () => [...document.links].map((a) => a.href))) || []);
      return await Promise.all((args.urls || []).slice(0, 4).map((u) => (links.has(String(u)) ? readLinked(String(u)) : { url: String(u), text: "", refused: "not a link on this page" })));
    }
    default:
      throw new Error(`unknown request: ${op}`);
  }
}

/**
 * Blackboard's own API, read with your Blackboard sign-in (Izuki never sees a
 * password). Only GET, only Blackboard's /learn/api/ paths: nothing else can
 * be fetched this way, and nothing can be changed.
 */
async function bbFetch(url) {
  let u;
  try {
    u = new URL(url);
  } catch {
    throw new Error("not a web address");
  }
  if (u.protocol !== "https:" || !u.pathname.startsWith("/learn/api/")) throw new Error("only Blackboard's read-only API can be fetched");
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const r = await fetch(u.href, { credentials: "include", signal: ctrl.signal, headers: { Accept: "application/json" } });
    const text = (await r.text()).slice(0, 2000000);
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      /* not JSON: a sign-in page */
    }
    return { status: json === null && r.ok ? 401 : r.status, json };
  } finally {
    clearTimeout(timer);
  }
}

/** A linked page's words (no scripts or menus), read in the background. */
async function readLinked(url) {
  try {
    if (!/^https?:/i.test(url)) return { url, text: "" };
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    const r = await fetch(url, { credentials: "include", signal: ctrl.signal, redirect: "follow" });
    clearTimeout(timer);
    const type = r.headers.get("content-type") || "";
    if (!r.ok || !/text\/html|text\/plain|application\/xhtml/.test(type)) return { url, text: "" };
    const html = (await r.text()).slice(0, 600000);
    const title = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || "";
    const text = html
      .replace(/<(script|style|noscript|svg|nav|header|footer|template)[\s\S]*?<\/\1>/gi, " ")
      .replace(/<br\s*\/?>|<\/(p|div|li|h[1-6]|tr)>/gi, "\n")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
      .replace(/[ \t]+/g, " ")
      .replace(/\n\s*\n+/g, "\n")
      .trim();
    return { url, title: title.trim(), text: text.slice(0, 3000) };
  } catch {
    return { url, text: "" };
  }
}

// ---- these run inside the page ---------------------------------------------

function snapshot() {
  const SEL = 'a[href],button,input:not([type=hidden]),select,textarea,summary,[role=button],[role=link],[role=tab],[role=menuitem],[role=checkbox],[role=radio],[role=option],[role=switch],[contenteditable="true"],[onclick]';
  // Passwords, card numbers, security and one-time codes: never typed by
  // Izuki, on any site. (Repeated in typeEl: each runs alone in the page.)
  const secret = (el) => {
    const type = (el.getAttribute("type") || "").toLowerCase();
    const ac = (el.getAttribute("autocomplete") || "").toLowerCase();
    const label = `${el.getAttribute("name") || ""} ${el.id || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("placeholder") || ""} ${[...(el.labels || [])].map((l) => l.textContent || "").join(" ")}`.toLowerCase();
    return type === "password" || /(^|\s)(current-password|new-password|one-time-code|cc-number|cc-csc|cc-exp)/.test(ac) || /\b(password|passcode|cvv|cvc|card ?number|security code|one.?time code|otp)\b/.test(label);
  };
  const kindOf = (el) => {
    const tag = el.tagName.toLowerCase();
    const role = (el.getAttribute("role") || "").toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (type === "checkbox" || role === "checkbox" || role === "switch") return "CheckBox";
    if (type === "radio" || role === "radio") return "RadioButton";
    if (tag === "select") return "ComboBox";
    if (tag === "input" && secret(el)) return "Secret";
    if (tag === "textarea" || el.isContentEditable || (tag === "input" && !["button", "submit", "reset", "image"].includes(type))) return "Edit";
    if (role === "tab") return "TabItem";
    if (role === "menuitem" || role === "option") return "MenuItem";
    if (tag === "a" || role === "link") return "Hyperlink";
    return "Button";
  };
  const nameOf = (el) => {
    const label = el.getAttribute("aria-label") || (el.labels && el.labels[0] && el.labels[0].innerText) || "";
    const text = (el.innerText || el.value || el.getAttribute("placeholder") || el.getAttribute("title") || "").trim();
    const img = el.querySelector && el.querySelector("img[alt]");
    return (label || text || (img && img.alt) || "").replace(/\s+/g, " ").trim().slice(0, 100);
  };
  const out = [];
  let n = Number(document.documentElement.getAttribute("data-izuki-next") || 1);
  for (const el of document.querySelectorAll(SEL)) {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2 || r.bottom < 0 || r.right < 0 || r.top > innerHeight || r.left > innerWidth) continue;
    const st = getComputedStyle(el);
    if (st.visibility === "hidden" || st.display === "none" || Number(st.opacity) === 0) continue;
    let id = el.getAttribute("data-izuki-id");
    if (!id) {
      id = `i${n++}`;
      el.setAttribute("data-izuki-id", id);
    }
    const href = el.tagName === "A" ? el.href : null;
    out.push({ id, kind: kindOf(el), name: nameOf(el), href, rect: { x: r.left, y: r.top, w: r.width, h: r.height } });
    if (out.length >= 150) break;
  }
  document.documentElement.setAttribute("data-izuki-next", String(n));
  return {
    text: (document.body ? document.body.innerText : "").replace(/\n{3,}/g, "\n\n").slice(0, 6000),
    elements: out,
    metrics: { dpr: devicePixelRatio, screenX, screenY, outerWidth, innerWidth, outerHeight, innerHeight },
  };
}

function clickEl(id) {
  const el = document.querySelector(`[data-izuki-id="${CSS.escape(id)}"]`);
  if (!el) return false;
  el.scrollIntoView({ block: "center", inline: "center" });
  if (el.focus) el.focus({ preventScroll: true });
  // The answer card must not sit over the control being pressed.
  try { globalThis.__izukiBubbleDodge?.(el.getBoundingClientRect()); } catch {}
  if (!el.isConnected) return false;
  // A click that leaves the page (a link, a submit) tears down this script
  // before its reply can travel back, and Izuki then waited out its whole
  // timeout to say "unconfirmed" about a click that had worked. So those are
  // reported a moment *before* they happen — with how long until they do,
  // so the app waits that long before it looks again. Without that, a look
  // inside the gap saw nothing changed and could click a second time.
  // Everything else is clicked first and reported after: no gap at all.
  const leaves = !!el.closest('a[href]:not([href^="#"]):not([href^="javascript:"]), button[type="submit"], input[type="submit"], input[type="image"]')
    || (el.tagName === "BUTTON" && !el.getAttribute("type") && !!el.form);
  if (!leaves) {
    el.click();
    return true;
  }
  const deferred = 90;
  return new Promise((done) => {
    done({ deferred });
    setTimeout(() => {
      // Re-checked at the last moment: a page that redrew in the gap is not
      // clicked blindly. The next look sees whatever it became.
      if (el.isConnected) el.click();
    }, deferred);
  });
}
function typeEl(id, text) {
  // Passwords, card numbers, security and one-time codes: never typed by
  // Izuki, on any site. (Repeated in typeEl: each runs alone in the page.)
  const secret = (el) => {
    const type = (el.getAttribute("type") || "").toLowerCase();
    const ac = (el.getAttribute("autocomplete") || "").toLowerCase();
    const label = `${el.getAttribute("name") || ""} ${el.id || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("placeholder") || ""} ${[...(el.labels || [])].map((l) => l.textContent || "").join(" ")}`.toLowerCase();
    return type === "password" || /(^|\s)(current-password|new-password|one-time-code|cc-number|cc-csc|cc-exp)/.test(ac) || /\b(password|passcode|cvv|cvc|card ?number|security code|one.?time code|otp)\b/.test(label);
  };
  const el = document.querySelector(`[data-izuki-id="${CSS.escape(id)}"]`);
  if (!el) return false;
  if (secret(el)) return "secret";
  el.scrollIntoView({ block: "center" });
  el.focus();
  try { globalThis.__izukiBubbleDodge?.(el.getBoundingClientRect()); } catch {}
  if (el.isContentEditable) {
    document.execCommand("selectAll", false);
    document.execCommand("insertText", false, text);
    return true;
  }
  // Frameworks (React, Vue…) watch the native setter and input events.
  const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value");
  if (setter && setter.set) setter.set.call(el, text);
  else el.value = text;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

/** Press YouTube's own visible ad-skip button, only while this tab is in front. */
function skipAd() {
  // Only YouTube, and only inside its player: a page's own "Skip" link is not
  // an ad. One query; each button is checked by its visible label.
  if (!/(^|\.)youtube\.com$/i.test(location.hostname)) return { skipped: false };
  const inFront = () => document.visibilityState === "visible" && document.hasFocus();
  if (!inFront()) return { skipped: false };
  const player = document.querySelector("#movie_player, .html5-video-player");
  if (!player) return { skipped: false };
  /** Is this exactly one of YouTube's ad-skip labels? */
  const skipName = (value) => {
    const name = String(value || "").toLowerCase().replace(/[^a-z0-9]+$/g, "").trim();
    return ["skip", "skip ad", "skip ads", "skip advertisement"].includes(name);
  };
  /** The first visible label on this button that means "skip this ad". */
  const labelOf = (el) => {
    for (const value of [el.getAttribute("aria-label"), el.textContent]) {
      const raw = String(value || "").replace(/\s+/g, " ").trim();
      if (raw && skipName(raw)) return raw.slice(0, 80);
    }
    return "";
  };
  for (const el of player.querySelectorAll('button, [role="button"]')) {
    if (el.disabled || el.getAttribute("aria-disabled") === "true") continue;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    if (r.width < 2 || r.height < 2 || r.bottom < 0 || r.right < 0 || r.top > innerHeight || r.left > innerWidth) continue;
    if (st.visibility === "hidden" || st.display === "none" || Number(st.opacity) === 0) continue;
    const label = labelOf(el);
    if (!label) continue;
    // Last check at the click itself, not only when the job arrived: a tab
    // switch in between must not click in the background.
    if (!inFront()) return { skipped: false };
    el.click();
    return { skipped: true, label };
  }
  return { skipped: false };
}

// ---- stay connected --------------------------------------------------------
chrome.runtime.onStartup.addListener(loop);
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("izuki", { periodInMinutes: 0.5 });
  loop();
});
chrome.alarms.onAlarm.addListener(loop);
loop();
